import React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import EditIcon from "@mui/icons-material/Edit";
import { Link } from "react-router-dom";
import { Checkbox } from "@mui/material";
import * as employeeService from "../services/employee";

const EmployeesTable = ({ employees, onDeleteEmployee, onUpdateChanged }) => {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Status</TableCell>
            <TableCell>Task</TableCell>
            {/* <TableCell>Email</TableCell> */}
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {employees.map((employee) => (
            <TableRow key={employee.id}>
              <TableCell>
                <Checkbox
                  name="completed"
                  checked={employee.completed}
                  onChange={() => onUpdateChanged(employee.id)}
                />
              </TableCell>

              {/* <TableCell>{employee.userId}</TableCell> */}
              <TableCell>{employee.title}</TableCell>
              <TableCell>
                <Link to={`/employees/${employee.id}/edit`}>
                  <IconButton>
                    <EditIcon />
                  </IconButton>
                </Link>

                <IconButton onClick={() => onDeleteEmployee(employee.id)}>
                  <DeleteIcon />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default EmployeesTable;
