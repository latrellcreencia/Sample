import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Grid,
  TextField,
} from "@mui/material";
import Joi from "joi";
import React, { useState } from "react";
import App from "../App.css";
import Typography from "@mui/material/Typography";
import * as authService from "../services/auth";

const NotFound = ({ onSubmit, initialValue }) => {
  const [form, setForm] = useState(
    initialValue || {
      title: "",
    }
  );

  const [errors, setErrors] = useState({});

  const schema = Joi.object({
    title: Joi.string().min(2).max(100).required(),
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    onSubmit(form);
  };

  const handleChange = ({ currentTarget: input }) => {
    setForm({
      ...form,
      [input.name]: input.value,
    });

    const { error } = schema
      .extract(input.name)
      .label(input.name)
      .validate(input.value);

    if (error) {
      setErrors({ ...errors, [input.name]: error.details[0].message });
    } else {
      delete errors[input.name];
      setErrors(errors);
    }
  };

  const isFormInvalid = () => {
    const result = schema.validate(form);

    return !!result.error;
  };
  const currentUser = authService.getCurrentUser();

  return (
    <>
      <Grid
        container
        component="form"
        justifyContent="center"
        onSubmit={handleSubmit}
      >
        {" "}
        <div class="container">
          <div class="wrapper">
            <section class="post">
              <header>View Posts</header>
              <div class="content">
                <img src="icons/logo.png" alt="" />
                <Typography
                  component="span"
                  variant="body1"
                  sx={{ marginRight: 2 }}
                >
                  {currentUser.name}
                </Typography>
              </div>

              <textarea
                placeholder="What's on your mind?"
                name="title"
                error={!!errors.title}
                helperText={errors.title}
                onChange={handleChange}
                value={form.title}
                variant="standard"
                fullWidth
              ></textarea>
              <button disabled={isFormInvalid()} type="submit" fullWidth>
                Post
              </button>
            </section>
          </div>
        </div>
        {/*<Grid item xs={6}>
          <Card>
            <CardHeader title={`${initialValue ? "Edit" : "Create"} Post`} />
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    name="title"
                    error={!!errors.title}
                    helperText={errors.title}
                    onChange={handleChange}
                    value={form.title}
                    label="..."
                    variant="standard"
                    fullWidth
                  />
                </Grid>
              </Grid>
            </CardContent>
            <CardActions>
              <button disabled={isFormInvalid()} type="submit" fullWidth>
                Submit
              </button>
            </CardActions>
          </Card>
  </Grid>*/}
      </Grid>
    </>
  );
};

export default NotFound;
