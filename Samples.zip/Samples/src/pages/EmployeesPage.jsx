import AddIcon from "@mui/icons-material/Add";
import { Button, Grid } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import EmployeesTable from "../components/EmployeesTable";
import * as employeeService from "../services/employee";
import * as authService from "../services/auth";
import jwtDecode from "jwt-decode";

const EmployeesPage = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    if (authService.getCurrentUser().isAdmin) {
      employeeService.fetchAllTasks().then((response) => {
        setEmployees(response.data);
      });
    } else {
      employeeService.fetchEmployees().then((response) => {
        setEmployees(response.data);
      });
    }
  }, []);

  const handleDeleteEmployee = async (id) => {
    const employeesClone = [...employees];

    try {
      setEmployees(employees.filter((employee) => employee.id !== id));
      await employeeService.deleteEmployee(id);
    } catch (error) {
      if (error.response && error.response.status === 404) {
        alert("Data might have already been deleted");
      }
      setEmployees(employeesClone);
    }
  };
  const handleUpdateChanged = (id) => {
    const employee = employees.find((employee) => employee.id === id);
    employee.completed = !employee.completed;
    employeeService.updateEmployee(id, employee);
    setEmployees(
      employees.map((employee) => {
        if (employee.id === id) {
          return {
            ...employee,
          };
        }
        return employee;
      })
    );
  };

  return (
    <Grid container spacing={2} justifyContent="flex-end" textAlign="right">
      <Grid item xs={4}>
        <Button
          variant="text"
          startIcon={<AddIcon />}
          LinkComponent={Link}
          to="/employees/new"
        >
          Add Task
        </Button>
      </Grid>
      <Grid item xs={12}>
        <EmployeesTable
          onDeleteEmployee={handleDeleteEmployee}
          onUpdateChanged={handleUpdateChanged}
          employees={employees}
        />
      </Grid>
    </Grid>
  );
};

export default EmployeesPage;
